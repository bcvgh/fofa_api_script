例:python3 fofa_api_script.py -s 'shiro'

执行python3 fofa_api_script.py --help 查看所有参数

